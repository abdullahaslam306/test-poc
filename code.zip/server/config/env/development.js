"use strict";
module.exports = {
  PORT: 3000,
  MONGODB_URI: "mongodb://localhost:27017/LegendaryVault",
  secret: "secret",
  host: "localhost:5000",
};